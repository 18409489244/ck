# ip2region php5 c 扩展查询客户端实现

# 使用方式

# 查询测试

# bench 测试
